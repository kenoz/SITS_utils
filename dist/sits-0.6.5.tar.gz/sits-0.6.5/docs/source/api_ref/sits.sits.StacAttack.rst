﻿sits.sits.StacAttack
====================

.. currentmodule:: sits.sits

.. autoclass:: StacAttack

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~StacAttack.__init__
      ~StacAttack.fixS2shift
      ~StacAttack.gapfill
      ~StacAttack.loadCube
      ~StacAttack.mask
      ~StacAttack.mask_apply
      ~StacAttack.searchItems
      ~StacAttack.spectral_index
      ~StacAttack.to_csv
      ~StacAttack.to_nc
   
   

   
   
   