﻿sits.sits.def\_geobox
=====================

.. currentmodule:: sits.sits

.. autofunction:: def_geobox