sits sub-packages
=================

The Sits_ds class
*****************
.. autoclass:: sits.export.Sits_ds
   :members:
   :undoc-members:
   :show-inheritance: