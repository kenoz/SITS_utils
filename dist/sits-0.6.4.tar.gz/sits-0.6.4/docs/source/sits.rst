The SITS Module
===============

sits.sits
---------------
.. automodule:: sits.sits
    :members:
