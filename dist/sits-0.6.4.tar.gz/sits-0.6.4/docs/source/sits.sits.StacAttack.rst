sits.sits.StacAttack
==============================

.. currentmodule:: sits.sits

.. autoclass:: StacAttack