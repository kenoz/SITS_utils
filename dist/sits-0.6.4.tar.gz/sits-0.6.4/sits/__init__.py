"""spyndex - Awesome Spectral Indices in Python"""

__version__ = "0.6.4"
__author__ = "Kenji Ose <kenji.ose@ec.europa.eu>"
__all__ = []

from . import sits, export