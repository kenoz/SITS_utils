Module export
=============

Here you will find all sits methods:

sits.export
-----------

Core module of spyndex. All functions here are automatically loaded with :code:`import sits`
and can be called from it:

.. currentmodule:: sits.export
   
.. autoclass:: Sits_ds
   :members:
   :undoc-members:
   :show-inheritance: