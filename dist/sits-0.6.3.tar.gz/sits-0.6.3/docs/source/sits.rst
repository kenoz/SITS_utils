The SITS Module
===============
   
The def_geobox function
***********************
.. autofunction:: sits.def_geobox

The def_geobox function
***********************
.. autofunction:: def_geobox

The def_geobox function
***********************
.. autofunction:: sits.sits.def_geobox



The Gdfgeom class
*****************
.. autoclass:: sits.Gdfgeom
   :members:
   :undoc-members:
   :show-inheritance: